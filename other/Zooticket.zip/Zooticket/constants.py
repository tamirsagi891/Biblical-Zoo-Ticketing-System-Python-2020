PATH = 'chromedriver.exe'


CN_LOGIN_LINK = 'https://cpnclub.co.il/suppliers#/login'


HT_LOGIN_LINK = 'https://vpossimple.mltp.co.il/index.php'
HT_USERNAME = '89zoo'
HT_PASSWORD = '89zoo'
HT_ID_NUM = '1568'

HT_USERNAME_BOX = '//*[@id="username"]'
HT_PASSWORD_BOX = '/html/body/div[4]/div/div/div[1]/div/div[2]/div/div/form/div[2]/input'
HT_ID_NUM_BOX = '/html/body/div[4]/div/div/div[1]/div/div[2]/div/div/form/div[3]/input'
HT_BUTTON = '/html/body/div[4]/div/div/div[1]/div/div[2]/div/div/form/div[5]/div/div/button'