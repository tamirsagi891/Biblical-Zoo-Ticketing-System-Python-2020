import tkinter as tk
from tkinter import filedialog, Text, ttk, Label
from main import *
from PIL import Image, ImageTk


def send_code(event=None):
    code = textBox.get("1.0", "end-1c")
    outcome = get_ticket(code)
    if outcome != '1':
        screen['text'] = outcome
    else:
        textBox.delete("1.0", "end")


root = tk.Tk()
root.title('גן החיות התנכי')
root.resizable(width=False, height=False)

canvas = tk.Canvas(root, heigh=400, width=450)
canvas.pack()

frame = tk.Frame(root, bg='green4')
frame.place(relwidth=1, relheight=1)

screen = Label(frame, text='הכנס קוד', bg='green4', font="Times 20 bold")
screen.grid(column=0, row=1,  padx=5, pady=5)

textBox = Text(frame, height=1, width=35, padx=10, pady=5, font="Times 14 bold")
textBox.grid(column=0, row=2, padx=5, pady=5)

submit_button = tk.Button(frame, text="שלח קוד", command=send_code, pady=3, padx=100, font="Times 14 bold")
submit_button.grid(column=0, row=3, pady=5)

image1 = Image.open('im1.jpg')
image1 = image1.resize((450, 250), Image.ANTIALIAS)
test = ImageTk.PhotoImage(image1)

label1 = tk.Label(frame, image=test)
label1.image = test

label1.grid(column=0, row=4, pady=5)

root.mainloop()
